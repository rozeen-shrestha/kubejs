// ================================================================
//  HUNGER GAMES — Custom Weapons (Flaming Khukuri)
//  KubeJS 6 / Fabric / Minecraft 1.20.1
//  
//  Adds the Flaming Khukuri and Compressed Blaze Rod recipes,
//  and custom combat damage effects.
// ================================================================

// 1. Register recipes
ServerEvents.recipes(event => {
    // Recipe: 3x3 Blaze Rods -> 1 Compressed Blaze Rod (with Enchantment Glow and Custom NBT)
    event.shaped(
        Item.of('minecraft:blaze_rod', {
            display: {
                Name: '{"text":"Compressed Blaze Rod","color":"gold","bold":true,"italic":false}',
            },
            CompressedBlazeRod: 1,
            Enchantments: [] // Adds the enchanted glint without actual enchantments
        }),
        [
            'BBB',
            'BBB',
            'BBB'
        ],
        {
            B: 'minecraft:blaze_rod'
        }
    ).id('hungergames:compressed_blaze_rod');

    // Recipe: Flaming Khukuri using Magma Cream, Blaze Rods, Netherite Sword, and Leather
    event.shaped(
        Item.of('minecraft:netherite_sword', {
            Enchantments: [
                { id: 'minecraft:fire_aspect', lvl: 2 },
                { id: 'minecraft:sharpness', lvl: 5 }
            ],
            display: {
                Name: '{"text":"Flaming Khukuri","color":"gold","bold":true,"italic":false}',
            },
            CustomWeapon: 'flaming_khukuri',
            CustomModelData: 1,
            Unbreakable: 1
        }),
        [
            ' M ',
            'BSB',
            ' L '
        ],
        {
            M: Item.of('minecraft:magma_cream', 4),
            B: Item.of('minecraft:blaze_rod', 8),
            S: 'minecraft:netherite_sword',
            L: Item.of('minecraft:leather', 16)
        }
    ).id('hungergames:flaming_khukuri');

    // Recipe: Sherpa's Pickaxe
    event.shaped(
        Item.of('minecraft:diamond_pickaxe', {
            display: {
                Name: '{"text":"Sherpa\'s Pickaxe","color":"aqua","bold":true,"italic":false}',
                Lore: [
                    '[{"text":"Auto-smelts mined ores and grants furnace EXP.","color":"gray","italic":false}]',
                    '[{"text":"Has a chance to find bonus smelted ores!","color":"gold","italic":false}]'
                ]
            },
            CustomTool: 'sherpa_pickaxe',
            CustomModelData: 1,
            Unbreakable: 1
        }),
        [
            'DDI',
            ' S ',
            ' I '
        ],
        {
            D: 'minecraft:diamond',
            I: 'minecraft:iron_ingot',
            S: 'minecraft:stick'
        }
    ).id('hungergames:sherpas_pickaxe');
});

// 2. Combat effects (additional fire aspect damage)
EntityEvents.hurt(event => {
    let attacker = event.attacker;
    if (!attacker) return;

    // Check if the attacker is holding the Flaming Khukuri
    let weapon = attacker.mainHandItem;
    if (weapon && weapon.id === 'minecraft:netherite_sword' && weapon.nbt && weapon.nbt.toString().includes('flaming_khukuri')) {
        // Increase damage (add 6 extra damage to normal hits)
        event.amount = event.amount + 6.0;

        // Set victim on fire (7 seconds)
        try {
            event.entity.setSecondsOnFire(7);
        } catch (e) { }
    }
});
