// ================================================================
//  HUNGER GAMES — Airdrop Event System
//  KubeJS 6 / Fabric / Minecraft 1.20.1
//  Converted from: hg-airdrop.sk
//
//  Glowing chickens descend from y=200, dropping loot chests on landing.
//  Supports multiple concurrent airdrops.
// ================================================================

// Safety: ensure global state exists regardless of load order
if (!global.HG) global.HG = { cfg: { prefix: '§6[HG]' }, game: { running: false }, nether: { locked: false }, alive: {}, spawns: {}, tick: 0 };
if (!global.HG.fn) global.HG.fn = {};
if (global.HG.airdrops === undefined) global.HG.airdrops = [];

var IntegerArgumentType_AD = Java.loadClass('com.mojang.brigadier.arguments.IntegerArgumentType');

// ════════════════════════════════════
//  LAUNCH AIRDROP
// ════════════════════════════════════

global.HG.fn.launchAirdrop = function(server, x, z, worldId) {
    var HG = global.HG;

    // Round coordinates
    x = Math.floor(x);
    z = Math.floor(z);
    var wId = worldId || 'minecraft:overworld';

    // Generate unique ID tag
    var uniqueId = 'hg_ad_' + Math.floor(Math.random() * 1000000);

    // Summon a glowing, invulnerable chicken at y=200 with NoGravity + NoAI
    // Tagged specifically with hg_airdrop AND its unique ID
    server.runCommandSilent(
        'summon chicken ' + x + ' 200 ' + z +
        ' {Tags:["hg_airdrop","' + uniqueId + '"],' +
        'NoGravity:1b,NoAI:1b,Silent:1b,Invulnerable:1b,' +
        'CustomName:\'{"text":"§dAIRDROP","italic":false}\',' +
        'CustomNameVisible:1b,Glowing:1b,' +
        'Attributes:[{Name:"generic.max_health",Base:2000.0}],' +
        'Health:2000.0f}'
    );

    // Push into active tracker
    global.HG.airdrops.push({
        tag: uniqueId,
        x: x,
        z: z,
        y: 200,
        world: wId
    });

    HG.fn.broadcast(server, HG.cfg.prefix + ' §dAirdrop incoming at §f' + x + '§7, §f' + z + '§7.');
};

// ════════════════════════════════════
//  FALL DETECTION (tick-based)
// ════════════════════════════════════

ServerEvents.tick(function(event) {
    var HG = global.HG;
    if (!HG.airdrops || HG.airdrops.length === 0) return;

    var server = event.server;

    // Run every 4 ticks (~5 blocks/sec descent speed)
    if (HG.tick % 4 !== 0) return;

    for (var i = HG.airdrops.length - 1; i >= 0; i--) {
        var ad = HG.airdrops[i];

        // Guard: check if the specific chicken entity still exists in the world
        var chickenExists = server.runCommandSilent(
            'execute if entity @e[tag=' + ad.tag + ',limit=1]'
        );
        if (chickenExists === 0) {
            // Remove from tracking if killed/deleted
            HG.airdrops.splice(i, 1);
            continue;
        }

        // Move chicken down by 1 block
        ad.y -= 1;

        // Teleport the specific chicken entity
        server.runCommandSilent(
            'tp @e[tag=' + ad.tag + ',limit=1] ' +
            ad.x + ' ' + ad.y + ' ' + ad.z
        );

        // Safety: abort if below y=0
        if (ad.y <= 0) {
            server.runCommandSilent('kill @e[tag=' + ad.tag + ']');
            HG.airdrops.splice(i, 1);
            HG.fn.landAirdrop(server, ad.x, 1, ad.z, ad.world);
            continue;
        }

        // Only start ground-checking after descending at least 5 blocks
        if (ad.y > 195) continue;

        // Check if the block at the chicken's position is NOT air (hit solid block/ground)
        var inAir = server.runCommandSilent(
            'execute at @e[tag=' + ad.tag + ',limit=1] if block ~ ~ ~ minecraft:air'
        );
        var inWater = server.runCommandSilent(
            'execute at @e[tag=' + ad.tag + ',limit=1] if block ~ ~ ~ minecraft:water'
        );
        var inCaveAir = server.runCommandSilent(
            'execute at @e[tag=' + ad.tag + ',limit=1] if block ~ ~ ~ minecraft:cave_air'
        );

        // Also check block BELOW for landing on surface
        var solidBelow = 0;
        if (inAir > 0 || inWater > 0 || inCaveAir > 0) {
            var checkInAirBelow = server.runCommandSilent(
                'execute at @e[tag=' + ad.tag + ',limit=1] if block ~ ~-1 ~ minecraft:air'
            );
            var checkInWaterBelow = server.runCommandSilent(
                'execute at @e[tag=' + ad.tag + ',limit=1] if block ~ ~-1 ~ minecraft:water'
            );
            var checkInCaveBelow = server.runCommandSilent(
                'execute at @e[tag=' + ad.tag + ',limit=1] if block ~ ~-1 ~ minecraft:cave_air'
            );
            if (checkInAirBelow === 0 && checkInWaterBelow === 0 && checkInCaveBelow === 0) {
                solidBelow = 1; // Block below is solid!
            }
        }

        // Landing condition: either inside a solid block, or standing on solid ground
        if ((inAir === 0 && inWater === 0 && inCaveAir === 0) || solidBelow > 0) {
            // Kill the chicken
            server.runCommandSilent('kill @e[tag=' + ad.tag + ']');
            HG.airdrops.splice(i, 1);
            HG.fn.landAirdrop(server, ad.x, ad.y, ad.z, ad.world);
        }
    }
});

// ════════════════════════════════════
//  LANDING — Place chest with loot
// ════════════════════════════════════

global.HG.fn.landAirdrop = function(server, x, y, z, worldId) {
    var HG = global.HG;

    // Walk down to find ground (check up to 15 blocks below)
    var groundY = y;
    for (var dy = 0; dy >= -15; dy--) {
        // Check if the block is solid (unless block is air)
        var isSolid = server.runCommandSilent(
            'execute in ' + worldId + ' unless block ' + x + ' ' + (y + dy) + ' ' + z + ' minecraft:air'
        );
        if (isSolid > 0) {
            // Found solid block! Place chest 1 block above it
            groundY = y + dy + 1;
            break;
        }
    }

    // Place chest at ground level
    server.runCommandSilent(
        'execute in ' + worldId + ' run setblock ' + x + ' ' + groundY + ' ' + z + ' minecraft:chest replace'
    );

    // Small delay to let the chest register, then fill with loot
    server.scheduleInTicks(2, function() {
        // Fill chest with loot using item replace
        server.runCommandSilent('item replace block ' + x + ' ' + groundY + ' ' + z + ' container.4 with minecraft:diamond 2');
        server.runCommandSilent('item replace block ' + x + ' ' + groundY + ' ' + z + ' container.13 with minecraft:golden_apple 3');
        server.runCommandSilent('item replace block ' + x + ' ' + groundY + ' ' + z + ' container.22 with minecraft:iron_ingot 16');
        server.runCommandSilent('item replace block ' + x + ' ' + groundY + ' ' + z + ' container.10 with minecraft:cooked_beef 8');
        server.runCommandSilent('item replace block ' + x + ' ' + groundY + ' ' + z + ' container.16 with minecraft:arrow 32');
        server.runCommandSilent('item replace block ' + x + ' ' + groundY + ' ' + z + ' container.1 with minecraft:bow 1');
        server.runCommandSilent('item replace block ' + x + ' ' + groundY + ' ' + z + ' container.25 with minecraft:iron_sword 1');
    });

    // Explosion sound
    server.runCommandSilent(
        'execute in ' + worldId + ' run playsound minecraft:entity.generic.explode master @a ' +
        x + ' ' + groundY + ' ' + z + ' 1.5 0.7'
    );

    // Celebration fireworks (12 rockets, staggered)
    for (var i = 0; i < 12; i++) {
        (function(index) {
            server.scheduleInTicks(index * 4, function() {
                var fx = x + Math.floor(Math.random() * 7) - 3;
                var fz = z + Math.floor(Math.random() * 7) - 3;
                server.runCommandSilent(
                    'execute in ' + worldId + ' run summon firework_rocket ' +
                    fx + ' ' + groundY + ' ' + fz +
                    ' {LifeTime:10,Fireworks:{Flight:0b,Explosions:[{' +
                    'Type:1,Flicker:1b,Trail:1b,' +
                    'Colors:[I;16711680,16753920,16776960],' +
                    'FadeColors:[I;16777215]}]}}'
                );
            });
        })(i);
    }

    // Launch sound
    server.scheduleInTicks(4, function() {
        server.runCommandSilent(
            'execute in ' + worldId + ' run playsound minecraft:entity.firework_rocket.launch master @a ' +
            x + ' ' + groundY + ' ' + z + ' 1 0.8'
        );
    });

    // Broadcast landing message
    HG.fn.broadcast(server, HG.cfg.prefix + ' §dAirdrop landed. Loot chest at §f' + x + ', ' + groundY + ', ' + z + '§7.');
};

// ════════════════════════════════════
//  /airdrop COMMAND
// ════════════════════════════════════

ServerEvents.commandRegistry(function(event) {
    var C = event.commands;

    event.register(
        C.literal('airdrop')
            .requires(function(src) { return src.hasPermission(2); })

            // /airdrop spawn — launch at player's location
            .then(C.literal('spawn').executes(function(ctx) {
                var p;
                try { p = ctx.source.playerOrException; } catch(e) { return 0; }
                var server = ctx.source.getServer();
                var worldId = p.level.dimension.toString();
                global.HG.fn.launchAirdrop(server, p.x, p.z, worldId);
                return 1;
            }))
            .then(C.literal('launch').executes(function(ctx) {
                var p;
                try { p = ctx.source.playerOrException; } catch(e) { return 0; }
                var server = ctx.source.getServer();
                var worldId = p.level.dimension.toString();
                global.HG.fn.launchAirdrop(server, p.x, p.z, worldId);
                return 1;
            }))

            // /airdrop at <x> <z> — launch at specific coordinates
            .then(C.literal('at')
                .then(C.argument('x', IntegerArgumentType_AD.integer())
                    .then(C.argument('z', IntegerArgumentType_AD.integer())
                        .executes(function(ctx) {
                            var p;
                            try { p = ctx.source.playerOrException; } catch(e) { return 0; }
                            var server = ctx.source.getServer();
                            var ax = IntegerArgumentType_AD.getInteger(ctx, 'x');
                            var az = IntegerArgumentType_AD.getInteger(ctx, 'z');
                            var worldId = p.level.dimension.toString();
                            global.HG.fn.launchAirdrop(server, ax, az, worldId);
                            return 1;
                        })
                    )
                )
            )

            // /airdrop (no args) — launch at player's location
            .executes(function(ctx) {
                var p;
                try { p = ctx.source.playerOrException; } catch(e) { return 0; }
                var server = ctx.source.getServer();
                var worldId = p.level.dimension.toString();
                global.HG.fn.launchAirdrop(server, p.x, p.z, worldId);
                return 1;
            })
    );
});
