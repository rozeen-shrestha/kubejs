// ================================================================
//  HUNGER GAMES — Spawn Region Protection
//  KubeJS 6 / Fabric / Minecraft 1.20.1
//
//  Commands (OP only, under /hg):
//    /hg region give    — gives the Region Selector stick
//    /hg region confirm — saves the two selected corners
//    /hg region clear   — removes the region
//    /hg region info    — shows current region bounds
//
//  Block logic:
//    - Original blocks inside the region cannot be broken by players
//    - Players CAN place blocks inside the region; they auto-remove in 5s
//    - Player-placed blocks can be manually broken before the timer
//
//  Edit PLACED_LIFETIME_TICKS below to change the removal delay.
// ================================================================

// ── State init ──────────────────────────────────────────────────
if (!global.HG)       global.HG       = {};
if (!global.HG.fn)    global.HG.fn    = {};

// Active region bounds { minX, minY, minZ, maxX, maxY, maxZ } or null
if (global.HG.region    === undefined) global.HG.region    = null;
// Per-player wand selection { uuid: { c1:{x,y,z}, c2:{x,y,z} } }
if (global.HG.regionSel === undefined) global.HG.regionSel = {};
// Set of "x,y,z" keys for player-placed blocks (allows them to be broken)
if (global.HG.placed    === undefined) global.HG.placed    = {};
if (global.HG.breakerCounter === undefined) global.HG.breakerCounter = 1000;

// ── Tunable constant ───────────────────────────────────────────
var REGION_FILE          = 'kubejs/hg_spawn_region.json';
var PLACED_LIFETIME_TICKS = 200; // 10 seconds @ 20 TPS

// ── Cache a server reference for use inside block events ────────
// scheduleInTicks needs a server object; block events don't expose one directly.
ServerEvents.tick(function (event) {
    global.HG._srv = event.server;
});

// ════════════════════════════════════════════════════════
//  PERSISTENCE
// ════════════════════════════════════════════════════════

global.HG.fn.saveRegion = function () {
    try {
        // Always write a plain JS object so JsonIO serialises it cleanly
        var payload = global.HG.region
            ? {
                minX: global.HG.region.minX, minY: global.HG.region.minY, minZ: global.HG.region.minZ,
                maxX: global.HG.region.maxX, maxY: global.HG.region.maxY, maxZ: global.HG.region.maxZ
              }
            : {};
        JsonIO.write(REGION_FILE, payload);
        console.info('[HG Protection] Region saved to ' + REGION_FILE + '.');
    } catch (e) {
        console.error('[HG Protection] saveRegion failed: ' + e);
    }
};

global.HG.fn.loadRegion = function () {
    try {
        var data = JsonIO.read(REGION_FILE);
        // JsonIO returns a Java JsonObject; .get() returns JsonElement or null
        if (data == null) { global.HG.region = null; console.info('[HG Protection] No region file.'); return; }

        // Check for a valid field; empty object means cleared intentionally
        // JsonIO.read returns plain Java primitives (int/double), NOT JsonElement.
        // Use Number() to coerce them safely to JS numbers.
        var minXVal = data.get('minX');
        if (minXVal == null) { global.HG.region = null; console.info('[HG Protection] Region file is empty (cleared).'); return; }

        global.HG.region = {
            minX: Math.floor(Number(data.get('minX'))),
            minY: Math.floor(Number(data.get('minY'))),
            minZ: Math.floor(Number(data.get('minZ'))),
            maxX: Math.floor(Number(data.get('maxX'))),
            maxY: Math.floor(Number(data.get('maxY'))),
            maxZ: Math.floor(Number(data.get('maxZ')))
        };
        var r = global.HG.region;
        console.info(
            '[HG Protection] Loaded region: (' + r.minX + ',' + r.minY + ',' + r.minZ +
            ') → (' + r.maxX + ',' + r.maxY + ',' + r.maxZ + ')'
        );
    } catch (e) {
        console.error('[HG Protection] loadRegion failed: ' + e);
        global.HG.region = null;
    }
};

// Load immediately on script evaluation (captures /reload changes)
global.HG.fn.loadRegion();

// ════════════════════════════════════════════════════════
//  GEOMETRY HELPERS
// ════════════════════════════════════════════════════════

global.HG.fn.isInRegion = function (x, y, z) {
    var r = global.HG.region;
    if (!r) return false;
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    return x >= r.minX && x <= r.maxX
        && y >= r.minY && y <= r.maxY
        && z >= r.minZ && z <= r.maxZ;
};

global.HG.fn.regionFromCorners = function (c1, c2) {
    return {
        minX: Math.min(Math.floor(c1.x), Math.floor(c2.x)),
        minY: Math.min(Math.floor(c1.y), Math.floor(c2.y)),
        minZ: Math.min(Math.floor(c1.z), Math.floor(c2.z)),
        maxX: Math.max(Math.floor(c1.x), Math.floor(c2.x)),
        maxY: Math.max(Math.floor(c1.y), Math.floor(c2.y)),
        maxZ: Math.max(Math.floor(c1.z), Math.floor(c2.z))
    };
};

// ════════════════════════════════════════════════════════
//  INTERNAL HELPERS
// ════════════════════════════════════════════════════════

function posKey(x, y, z) {
    return Math.floor(x) + ',' + Math.floor(y) + ',' + Math.floor(z);
}

function isOp(player) {
    if (player == null) return false;
    try { if (player.hasPermissions) return player.hasPermissions(2); } catch (e) {}
    try { return player.server.getPlayerList().isOp(player.gameProfile); } catch (e) {}
    return false;
}

function getSoundGroup(blockId) {
    if (!blockId) return 'stone';
    blockId = String(blockId).toLowerCase();
    if (blockId.indexOf('wood') !== -1 || blockId.indexOf('planks') !== -1 || blockId.indexOf('log') !== -1 || blockId.indexOf('fence') !== -1 || blockId.indexOf('door') !== -1) {
        return 'wood';
    }
    if (blockId.indexOf('grass') !== -1 || blockId.indexOf('dirt') !== -1) {
        return 'grass';
    }
    if (blockId.indexOf('sand') !== -1) {
        return 'sand';
    }
    if (blockId.indexOf('gravel') !== -1) {
        return 'gravel';
    }
    if (blockId.indexOf('wool') !== -1 || blockId.indexOf('carpet') !== -1) {
        return 'wool';
    }
    if (blockId.indexOf('glass') !== -1) {
        return 'glass';
    }
    return 'stone';
}

function isHoldingSelector(item) {
    if (!item || item.empty) return false;
    // Must be a stick
    var id = '';
    try { id = String(item.id || item.getId() || ''); } catch (e) {}
    if (id.indexOf('stick') === -1) return false;
    // Must have "Region Selector" in its NBT or display name
    try { if (item.nbt && item.nbt.toString().indexOf('Region Selector') !== -1) return true; } catch (e) {}
    try {
        var name = '';
        if      (item.getHoverName)   { var n  = item.getHoverName();   name = n.getString ? n.getString() : String(n); }
        else if (item.getName)        { var n2 = item.getName();        name = n2.getString ? n2.getString() : String(n2); }
        else if (item.getDisplayName) { var n3 = item.getDisplayName(); name = n3.getString ? n3.getString() : String(n3); }
        if (name.indexOf('Region Selector') !== -1) return true;
    } catch (e) {}
    return false;
}

function tell(server, username, msg) {
    server.runCommandSilent('tellraw ' + username + ' {"text":"' + msg + '","italic":false}');
}

// ════════════════════════════════════════════════════════
//  CORNER SELECTION — Right-click = Corner 1
// ════════════════════════════════════════════════════════

BlockEvents.rightClicked(function (event) {
    var player = event.player;
    if (player == null) return;
    if (!isOp(player)) return;
    if (!isHoldingSelector(player.mainHandItem)) return;

    var bx = Math.floor(event.block.x);
    var by = Math.floor(event.block.y);
    var bz = Math.floor(event.block.z);
    var uuid = player.uuid.toString();

    if (!global.HG.regionSel[uuid]) global.HG.regionSel[uuid] = {};
    global.HG.regionSel[uuid].c1 = { x: bx, y: by, z: bz };

    tell(player.server, player.username,
        '§b[HG Region] §fCorner 1 §7→ §f(' + bx + ', ' + by + ', ' + bz + ')');
    console.info('[HG Protection] ' + player.username + ' set C1 at ' + bx + ',' + by + ',' + bz);
    event.cancel();
});

// ════════════════════════════════════════════════════════
//  CORNER SELECTION — Left-click = Corner 2
// ════════════════════════════════════════════════════════

BlockEvents.leftClicked(function (event) {
    var player = event.player;
    if (player == null) return;
    if (!isOp(player)) return;
    if (!isHoldingSelector(player.mainHandItem)) return;

    var bx = Math.floor(event.block.x);
    var by = Math.floor(event.block.y);
    var bz = Math.floor(event.block.z);
    var uuid = player.uuid.toString();

    if (!global.HG.regionSel[uuid]) global.HG.regionSel[uuid] = {};
    global.HG.regionSel[uuid].c2 = { x: bx, y: by, z: bz };

    tell(player.server, player.username,
        '§b[HG Region] §fCorner 2 §7→ §f(' + bx + ', ' + by + ', ' + bz +
        '). §aRun /hg region confirm to save!');
    console.info('[HG Protection] ' + player.username + ' set C2 at ' + bx + ',' + by + ',' + bz);
    event.cancel();
});

// ════════════════════════════════════════════════════════
//  BLOCK BREAK PROTECTION
// ════════════════════════════════════════════════════════

BlockEvents.broken(function (event) {
    if (!global.HG.region) return;

    var player = event.player;
    if (player == null) return;     // pistons, explosions, etc. — allowed
    if (isOp(player)) return;       // OPs bypass protection

    var bx = Math.floor(event.block.x);
    var by = Math.floor(event.block.y);
    var bz = Math.floor(event.block.z);

    if (!global.HG.fn.isInRegion(bx, by, bz)) return;

    var key = posKey(bx, by, bz);

    // Allow breaking a block the player themselves placed
    if (global.HG.placed[key] !== undefined) {
        delete global.HG.placed[key];
        console.info('[HG Protection] Allowed break of player-placed block at ' + key + ' by ' + player.username);
        return;
    }

    // Deny breaking original/protected block
    event.cancel();
    tell(player.server, player.username, '§cThis block is protected.');

    // Show block-crack particles and play a dig sound at the target position
    try {
        var blockId = event.block.id.toString();
        player.server.runCommandSilent(
            'particle block ' + blockId + ' ' +
            (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) +
            ' 0.3 0.3 0.3 0.05 20 force ' + player.username
        );
        player.server.runCommandSilent(
            'playsound minecraft:block.' + getSoundGroup(blockId) + '.hit block ' +
            player.username + ' ' + (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) + ' 1 0.8'
        );
    } catch (particleErr) {
        // Fallback: generic stone hit sound
        try {
            player.server.runCommandSilent(
                'playsound minecraft:block.stone.hit block ' +
                player.username + ' ' + (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) + ' 1 0.8'
            );
        } catch (e) {}
    }

    console.info('[HG Protection] Blocked break at ' + key + ' by ' + player.username);
});

// ════════════════════════════════════════════════════════
//  PLACED BLOCK TRACKING + AUTO-REMOVAL (scheduleInTicks)
// ════════════════════════════════════════════════════════

BlockEvents.placed(function (event) {
    if (!global.HG.region) return;

    var player = event.player;
    if (player == null) return;
    if (isOp(player)) return; // OPs bypass protection and their placed blocks are not auto-removed

    var bx = Math.floor(event.block.x);
    var by = Math.floor(event.block.y);
    var bz = Math.floor(event.block.z);

    if (!global.HG.fn.isInRegion(bx, by, bz)) return;

    var key = posKey(bx, by, bz);

    // Capture dimension string for the execute-in command
    var dim = 'minecraft:overworld';
    try { dim = String(event.level.dimension); } catch (e) {}

    // Store the current tick as a unique placement ID.
    // This lets the scheduled callback detect if the block was broken and
    // re-placed at the same spot — and skip the removal for the old timer.
    var placedAt = global.HG.tick || 0;
    global.HG.placed[key] = placedAt;

    console.info('[HG Protection] Placed block tracked at ' + key + ' (dim=' + dim + ', id=' + placedAt + ') — removing in ' + PLACED_LIFETIME_TICKS + ' ticks');

    // Use scheduleInTicks for reliable 5-second removal
    var srv = global.HG._srv;
    if (srv) {
        var pos = new BlockPos(bx, by, bz);
        var breakerId = global.HG.breakerCounter;
        global.HG.breakerCounter = breakerId + 1;

        // Stage 2 (40 ticks / 2s): crack stage 2, small smoke puff, hit sound
        srv.scheduleInTicks(40, function () {
            if (global.HG.placed[key] === placedAt) {
                var level = srv.getLevel(dim);
                if (level) {
                    level.destroyBlockProgress(breakerId, pos, 2);
                    var block = level.getBlock(bx, by, bz);
                    if (block && !block.air) {
                        srv.runCommandSilent('execute in ' + dim + ' run particle minecraft:smoke ' + (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) + ' 0.2 0.2 0.2 0.01 5 force @a');
                        srv.runCommandSilent('execute in ' + dim + ' run playsound minecraft:block.' + getSoundGroup(block.id.toString()) + '.hit block @a ' + (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) + ' 0.6 0.6');
                    }
                }
            }
        });

        // Stage 4 (80 ticks / 4s): crack stage 4, small smoke puff, hit sound
        srv.scheduleInTicks(80, function () {
            if (global.HG.placed[key] === placedAt) {
                var level = srv.getLevel(dim);
                if (level) {
                    level.destroyBlockProgress(breakerId, pos, 4);
                    var block = level.getBlock(bx, by, bz);
                    if (block && !block.air) {
                        srv.runCommandSilent('execute in ' + dim + ' run particle minecraft:smoke ' + (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) + ' 0.2 0.2 0.2 0.01 5 force @a');
                        srv.runCommandSilent('execute in ' + dim + ' run playsound minecraft:block.' + getSoundGroup(block.id.toString()) + '.hit block @a ' + (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) + ' 0.6 0.6');
                    }
                }
            }
        });

        // Stage 6 (120 ticks / 6s): crack stage 6, small smoke puff, hit sound
        srv.scheduleInTicks(120, function () {
            if (global.HG.placed[key] === placedAt) {
                var level = srv.getLevel(dim);
                if (level) {
                    level.destroyBlockProgress(breakerId, pos, 6);
                    var block = level.getBlock(bx, by, bz);
                    if (block && !block.air) {
                        srv.runCommandSilent('execute in ' + dim + ' run particle minecraft:smoke ' + (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) + ' 0.2 0.2 0.2 0.01 5 force @a');
                        srv.runCommandSilent('execute in ' + dim + ' run playsound minecraft:block.' + getSoundGroup(block.id.toString()) + '.hit block @a ' + (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) + ' 0.6 0.6');
                    }
                }
            }
        });

        // Stage 8 (160 ticks / 8s): crack stage 8, small smoke puff, hit sound
        srv.scheduleInTicks(160, function () {
            if (global.HG.placed[key] === placedAt) {
                var level = srv.getLevel(dim);
                if (level) {
                    level.destroyBlockProgress(breakerId, pos, 8);
                    var block = level.getBlock(bx, by, bz);
                    if (block && !block.air) {
                        srv.runCommandSilent('execute in ' + dim + ' run particle minecraft:smoke ' + (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) + ' 0.2 0.2 0.2 0.01 5 force @a');
                        srv.runCommandSilent('execute in ' + dim + ' run playsound minecraft:block.' + getSoundGroup(block.id.toString()) + '.hit block @a ' + (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) + ' 0.6 0.6');
                    }
                }
            }
        });

        // Stage 10 (200 ticks / 10s): remove block, clear progress, play break effects
        srv.scheduleInTicks(PLACED_LIFETIME_TICKS, function () {
            if (global.HG.placed[key] === placedAt) {
                delete global.HG.placed[key];
                try {
                    var level = srv.getLevel(dim);
                    if (level) {
                        level.destroyBlockProgress(breakerId, pos, -1);
                        var block = level.getBlock(bx, by, bz);
                        if (block && !block.air) {
                            var blockId = block.id.toString();
                            
                            // Spawn block break particles
                            srv.runCommandSilent(
                                'execute in ' + dim + ' run particle block ' + blockId + ' ' +
                                (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) +
                                ' 0.3 0.3 0.3 0.05 20 force @a'
                            );
                            // Play block break sound
                            srv.runCommandSilent(
                                'execute in ' + dim + ' run playsound minecraft:block.' + 
                                getSoundGroup(blockId) + '.break block @a ' +
                                (bx + 0.5) + ' ' + (by + 0.5) + ' ' + (bz + 0.5) + ' 1 0.8'
                            );
                        }
                    }
                    srv.runCommandSilent(
                        'execute in ' + dim + ' run setblock ' +
                        bx + ' ' + by + ' ' + bz + ' minecraft:air'
                    );
                    console.info('[HG Protection] Auto-removed block at ' + key);
                } catch (err) {
                    console.error('[HG Protection] Failed to remove block at ' + key + ': ' + err);
                }
            }
        });
    } else {
        console.warn('[HG Protection] _srv not yet available; block at ' + key + ' will NOT auto-remove.');
    }
});

// ════════════════════════════════════════════════════════
//  SERVER LOAD — reset runtime state, reload persisted region
// ════════════════════════════════════════════════════════

ServerEvents.loaded(function (event) {
    global.HG.placed    = {};
    global.HG.regionSel = {};
    global.HG.fn.loadRegion();
    console.info('[HG Protection] Protection loaded. Region active: ' + (global.HG.region !== null));
});
