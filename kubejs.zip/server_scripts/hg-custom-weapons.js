// ================================================================
//  HUNGER GAMES — Custom Weapons (Flaming Khukuri)
//  KubeJS 6 / Fabric / Minecraft 1.20.1
//  
//  Adds the Flaming Khukuri and Compressed Blaze Rod recipes,
//  and custom combat damage effects.
// ================================================================

// 1. Register recipes
ServerEvents.recipes(event => {
    // Recipe: 3x3 Blaze Rods -> 1 Compressed Blaze Rod (with Enchantment Glow and Custom NBT)
    event.shaped(
        Item.of('minecraft:blaze_rod', {
            display: {
                Name: '{"text":"Compressed Blaze Rod","color":"gold","bold":true,"italic":false}',
            },
            CompressedBlazeRod: 1,
            Enchantments: [] // Adds the enchanted glint without actual enchantments
        }),
        [
            'BBB',
            'BBB',
            'BBB'
        ],
        {
            B: 'minecraft:blaze_rod'
        }
    ).id('hungergames:compressed_blaze_rod');

    // Recipe: Flaming Khukuri using Magma Cream, Blaze Rods, Netherite Sword, and Leather
    event.shaped(
        Item.of('minecraft:netherite_sword', 1, '{display:{Name:\'{"text":"Flaming Khukuri","color":"gold","bold":true,"italic":false}\'},CustomWeapon:"flaming_khukuri",CustomModelData:1,Unbreakable:1b,AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"Weapon modifier",Amount:9.0d,Operation:0,UUID:[I;-885041709,1683771192,-1533574861,-1657510449],Slot:"mainhand"},{AttributeName:"generic.attack_speed",Name:"Weapon modifier",Amount:-2.4d,Operation:0,UUID:[I;-98353636,1098926181,-1340416820,-1396282157],Slot:"mainhand"}]}'),
        [
            ' M ',
            'BSB',
            ' L '
        ],
        {
            M: Item.of('minecraft:magma_cream', 4),
            B: Item.of('minecraft:blaze_rod', 8),
            S: 'minecraft:netherite_sword',
            L: Item.of('minecraft:leather', 16)
        }
    ).id('hungergames:flaming_khukuri');

    // Recipe: Sherpa's Pickaxe
    event.shaped(
        Item.of('minecraft:diamond_pickaxe', {
            display: {
                Name: '{"text":"Sherpa\'s Pickaxe","color":"aqua","bold":true,"italic":false}',
                Lore: [
                    '[{"text":"Auto-smelts mined ores and grants furnace EXP.","color":"gray","italic":false}]',
                    '[{"text":"Has a chance to find bonus smelted ores!","color":"gold","italic":false}]'
                ]
            },
            CustomTool: 'sherpa_pickaxe',
            CustomModelData: 1,
            Unbreakable: 1
        }),
        [
            'DDI',
            ' S ',
            ' I '
        ],
        {
            D: 'minecraft:diamond',
            I: 'minecraft:iron_ingot',
            S: 'minecraft:stick'
        }
    ).id('hungergames:sherpas_pickaxe');
});

// 2. Combat effects (additional fire aspect damage)
EntityEvents.hurt(event => {
    let attacker = event.source.actual || event.attacker;
    if (!attacker) return;

    // Check if the attacker is holding the Flaming Khukuri
    var weapon;
    try {
        weapon = attacker.mainHandItem || (attacker.getMainHandItem ? attacker.getMainHandItem() : null);
    } catch (e) {
        weapon = null;
    }

    if (weapon && weapon.id === 'minecraft:netherite_sword' && weapon.nbt && weapon.nbt.toString().includes('flaming_khukuri')) {
        // Increase damage (add 6 extra damage to normal hits)
        event.amount = event.amount + 6.0;

        // Set victim on fire (7 seconds = 140 ticks)
        try {
            event.entity.setRemainingFireTicks(140);
        } catch (e) {
            try {
                event.entity.setSecondsOnFire(7);
            } catch (e2) {
                console.error("[HG Custom Weapons] Failed to set victim on fire: " + e2);
            }
        }
    }
});
